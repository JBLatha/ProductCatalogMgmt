package com.product.catalouge.management.exception;

public class ProductNotFoundException extends RuntimeException {

		  public ProductNotFoundException(String exception) {
		    super(exception);
		  }

}
